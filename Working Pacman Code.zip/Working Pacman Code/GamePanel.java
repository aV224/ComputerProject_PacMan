import javax.swing.*;
import java.awt.*;
public class GamePanel extends JPanel{
    transient PacWall wall = new PacWall();

    public GamePanel() {
        setPreferredSize(new Dimension(560, 700));
    }
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        wall.drawWall(this.getWidth(), this.getHeight(), g);
    }
    
}
