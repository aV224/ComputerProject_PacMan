import javax.swing.*;
import java.awt.*;
public class GamePanel extends JPanel{
    public GamePanel() {
        //stuff
    }
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
    }
}
