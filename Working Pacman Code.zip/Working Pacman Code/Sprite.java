/**
* Sprite is the abstract base class for all sprite contexts
* Is an image that can be moved around
* @author Aiden Cheong
*/

import java.awt.image.BufferedImage;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
public class Sprite {
    /** 
     * image is the image that the sprite will load
     */
    BufferedImage image;
    BufferedImage imageRight;
    BufferedImage imageLeft;
    BufferedImage imageUp;
    BufferedImage imageDown;
    /** 
     * xPos stores the x coordinate of the sprite
     */
    protected int xPos;
    /**
     * yPos stores the y coordinate of the sprite
     */
    protected int yPos;
    protected int xv;
    protected int yv;
    /**
     * WIDTH stores the width of the sprite
     */
    private int width;
    /**
     * HEIGHT stores the height of the sprite
     */
    private int height;
    /**
     * direction stores either 0, 90, 180, or 270 which determines which direction the sprite is facing
     */
    protected int direction;
    /**
     * Constructor for the sprite
     * @param int a
     * @param int b
     * @param BufferedImage i
     */
    private PacWall wall;
    public Sprite(int x, int y, int w, int h, BufferedImage i, PacWall pwall) {
        xPos = x;
        yPos = y;
        width = w;
        height = h;
        image = i;
        imageRight = image;
        imageDown = rotateImage(imageRight, 90);
        imageLeft = rotateImage(imageDown, 90);
        imageUp = rotateImage(imageLeft, 90);
        wall = pwall;
    }
    /**
     * sets the x coordinate
     * @param x
     */
    public void setX(int x){
        xPos = x;
    }
    /**
     * gets the x coordinate
     * @return 
     */
    public int getX(){
        return xPos;
    }
    /**
     * sets the y coordinate
     * @param y
     */
    public void setY(int y){
        yPos = y;
    }
    /**
     * gets the y coordinate
     * @return
     */
    public int getY(){
        return yPos;
    }
    /**
     * gets the width
     * @return
     */
    public int getWidth(){
        return width;
    } 
    /**
     * gets the height
     * @return
     */
    public int getHeight(){
        return height;
    }
    /**
     * sets the direction of the sprite
     * @param d
     */
    public void setDirection(int d) {
        direction = d;
    }
    /**
     * gets the direction of the sprite
     * @return direction
     */
    public int getDirection() {
        return direction;
    }
    public int getXV() {
        return xv;
    }
    public int getYV() {
        return yv;
    }
    public PacWall getWall() {
        return wall;
    }
    /**
     * Rotates the sprite image
    */
    public BufferedImage rotateImage(BufferedImage img, double angle) {

        final double rads = Math.toRadians(90);
        final double sin = Math.abs(Math.sin(rads));
        final double cos = Math.abs(Math.cos(rads));
        final int w = (int) Math.floor(img.getWidth() * cos + img.getHeight() * sin);
        final int h = (int) Math.floor(img.getHeight() * cos + img.getWidth() * sin);
        final BufferedImage rotatedImage = new BufferedImage(w, h, img.getType());
        final AffineTransform at = new AffineTransform();
        at.translate(w / 2, h / 2);
        at.rotate(rads,0, 0);
        at.translate(-img.getWidth() / 2, -img.getHeight() / 2);
        final AffineTransformOp rotateOp = new AffineTransformOp(at, AffineTransformOp.TYPE_BILINEAR);
        rotateOp.filter(img,rotatedImage);

        return rotatedImage;
    }
    /**
     * displays the sprite. 
     * @param Graphics g
     * @param BufferedImage img
     */    
    public void display(Graphics g, BufferedImage img) {
        g.drawImage(img, xPos, yPos, width, height, null);
    }
    /**
     * Creates a "hitbox" around the sprite
     * @return Rectangle
    */
    public Rectangle getBounds() {
        return new Rectangle(this.xPos, this.yPos, this.width, this.height);
    }
    /**
     * Checks if the sprite has collided with another entity
     * @param b
     * @return
     */
    public boolean checkCollision(Sprite b) {
        return this.getBounds().intersects(b.getBounds());
    }
    /**
     * Changes the sprite image
     * @param a
     */
    public void changeImage(BufferedImage a) {
        this.image = a;
        imageRight = image;
        imageDown = rotateImage(imageRight, 90);
        imageLeft = rotateImage(imageDown, 90);
        imageUp = rotateImage(imageLeft, 90);
        if (direction == 90) {
            this.image = imageDown;
        }
        if (direction == 180) {
            this.image = imageLeft;
        }
        if (direction == 270) {
            this.image = imageUp;
        }
    }
    public boolean checkWalls(PacWall w, int x, int y) {
        Rectangle hitBox = new Rectangle(x, y, width, height);
        for (int i=0; i<w.getBounds().size(); i++) {
            Rectangle walls = w.getBounds().get(i);
            if (hitBox.intersects(walls)) {
                return true;
            }
        }
        return false;
    }
    public boolean leftIsClear(PacWall w) {
        return !checkWalls(w, xPos-10, yPos);
    }
    public boolean rightIsClear(PacWall w) {
        return !checkWalls(w, xPos+10, yPos);        
    }
    public boolean upIsClear(PacWall w) {
        return !checkWalls(w, xPos, yPos-10);
    }
    public boolean downIsClear(PacWall w) {
        return !checkWalls(w, xPos, yPos+10);
    }

    public void turnLeft() {
        setDirection(180);
        xv = -1;
        yv = 0;
    }
    public void turnRight() {
        setDirection(0);
        xv = 1;
        yv = 0;
    }
    public void turnUp() {
        setDirection(270);
        xv = 0;
        yv = -1;
    }
    public void turnDown() {
        setDirection(90);
        xv = 0;
        yv = 1;
    }
}
