/**
* Sprite is the abstract base class for all sprite contexts
* Is an image that can be moved around
* @author Aiden Cheong
*/

import java.awt.image.BufferedImage;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
public class Sprite {
    /** 
     * image is the image that the sprite will load
     */
    BufferedImage image;
    BufferedImage imageRight;
    BufferedImage imageLeft;
    BufferedImage imageUp;
    BufferedImage imageDown;
    /** 
     * xPos stores the x coordinate of the sprite
     */
    protected int xPos;
    /**
     * yPos stores the y coordinate of the sprite
     */
    protected int yPos;
    /**
    * speed stores the speed of the sprite
    */
    protected final int speed = 1;
    /**
     * WIDTH stores the width of the sprite
     */
    private int width;
    /**
     * HEIGHT stores the height of the sprite
     */
    private int height;
    /**
     * direction stores either 0, 90, 180, or 270 which determines which direction the sprite is facing
     */
    protected int direction;
    /**
     * Constructor for the sprite
     * @param int a
     * @param int b
     * @param BufferedImage i
     */
    public Sprite(int x, int y, BufferedImage i) {
        xPos = x;
        yPos = y;
        width = i.getWidth();
        height = i.getHeight();
        image = i;
        imageRight = image;
        imageDown = rotateImage(imageRight, 90);
        imageLeft = rotateImage(imageDown, 90);
        imageUp = rotateImage(imageLeft, 90);
        
    }
    /**
     * sets the x coordinate
     * @param x
     */
    public void setX(int x){ 
        this.xPos = x;
    }
    /**
     * gets the x coordinate
     * @return 
     */
    public int getX(){
        return xPos;
    }
    /**
     * sets the y coordinate
     * @param y
     */
    public void setY(int y){
        this.yPos = y;
    }
    /**
     * gets the y coordinate
     * @return
     */
    public int getY(){
        return yPos;
    }
    /**
     * gets speed
     * @return
     */
    public int getSpeed() {
    	return speed;
    }
    /**
     * gets the width
     * @return
     */
    public int getWidth(){
        return width;
    } 
    /**
     * gets the height
     * @return
     */
    public int getHeight(){
        return height;
    }
    /**
     * sets the direction of the sprite
     * @param d
     */
    public void setDirection(int d) {
        direction = d;
    }
    /**
     * gets the direction of the sprite
     * @return direction
     */
    public int getDirection() {
        return direction;
    }
    /**
     * Rotates the sprite image
    */
    public BufferedImage rotateImage(BufferedImage img, double angle) {

        final double rads = Math.toRadians(90);
        final double sin = Math.abs(Math.sin(rads));
        final double cos = Math.abs(Math.cos(rads));
        final int w = (int) Math.floor(img.getWidth() * cos + img.getHeight() * sin);
        final int h = (int) Math.floor(img.getHeight() * cos + img.getWidth() * sin);
        final BufferedImage rotatedImage = new BufferedImage(w, h, img.getType());
        final AffineTransform at = new AffineTransform();
        at.translate(w / 2, h / 2);
        at.rotate(rads,0, 0);
        at.translate(-img.getWidth() / 2, -img.getHeight() / 2);
        final AffineTransformOp rotateOp = new AffineTransformOp(at, AffineTransformOp.TYPE_BILINEAR);
        rotateOp.filter(img,rotatedImage);

        return rotatedImage;
    }
    /**
     * Scales the sprite's image
     * @param img
     * @param w
     * @param h
     * @return
     */
    public BufferedImage scaleImage(BufferedImage img, int w, int h) {
        Image toolkitImage = img.getScaledInstance(getWidth(), getHeight(), Image.SCALE_SMOOTH);
        int width1 = toolkitImage.getWidth(null);
        int height1 = toolkitImage.getHeight(null);

        // width and height are of the toolkit image
        BufferedImage newImage = new BufferedImage(width1, height1, BufferedImage.TYPE_INT_ARGB);
        return newImage;
    }
    /**
     * displays the sprite. You have to call it in the paintComponent() method in the panel.
     * @param g
     */    
    public void display(Graphics g, BufferedImage img) {
        g.drawImage(img, xPos, yPos, null);
    }
    /**
     * Creates a "hitbox" around the sprite
     * @return Rectangle
    */
    public Rectangle getBounds() {
        return new Rectangle(this.xPos, this.yPos, this.width, this.height);
    }
    /**
     * Checks if the sprite has collided with another sprite
     * @param b
     * @return
     */
    public boolean checkCollision(Sprite b) {
        if (this.getBounds().intersects(b.getBounds())) {
            return true;
        }
        else {
            return false;
        }
    }
    public void changeImage(BufferedImage a) {
        this.image = a;
        imageRight = image;
        imageDown = rotateImage(imageRight, 90);
        imageLeft = rotateImage(imageDown, 90);
        imageUp = rotateImage(imageLeft, 90);
        if (direction == 90) {
            this.image = imageDown;
        }
        if (direction == 180) {
            this.image = imageLeft;
        }
        if (direction == 270) {
            this.image = imageUp;
        }
    }
}
