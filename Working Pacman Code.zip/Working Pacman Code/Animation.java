import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;
public class Animation implements Runnable {

    private boolean running = false;
    private Thread thread;
    BufferedImage i = loadImage("pacman1.png");
    BufferedImage pelletImage = loadImage("Pellet.png");
    private ArrayList<Pellet> pelletList = new ArrayList<Pellet>();
    int[] pelletState;
    GamePanel game = new GamePanel();
    Rectangle boundaries = game.getBounds();
    Pacman p = new Pacman(21, 55, 15, 15, i, game.wall);
    Graphics g;
    private double current = 0;
    BufferedImage[] images = new BufferedImage[8];
    private int totalImages = images.length;
    BufferedImage[] losingImages = new BufferedImage[7];
    private double losingImage = 0;

    private BufferedImage[] createImages(BufferedImage[] x, String s) {
        BufferedImage[] imageArray = new BufferedImage[x.length];
        for (int k=0; k<x.length; k++) {
            int num = k+1;
            BufferedImage image = loadImage(s + num + ".png");
            imageArray[k] = image;
        }
        return imageArray;
    }
    
    private void init() {
        JFrame frame = new JFrame("test");
        frame.setSize(560, 700);
        frame.setLocation(200, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setContentPane(game); 
        frame.setVisible(true);
        frame.getContentPane().setFocusable(true);
        frame.getContentPane().setFocusTraversalKeysEnabled(false);
        frame.getContentPane().addKeyListener(new KeyInput(this));
        frame.getContentPane().setBackground(Color.BLACK);
        images = createImages(images, "pacman");
        losingImages = createImages(losingImages, "Wilting");
        createPellets();
    }
    int points = 0;
    private void tick() { //updates the gam
        current += 0.5;
        if (current >= totalImages) {
            current = 0;
        }
        for (int i=0; i<pelletList.size(); i++) {
            if (pelletList.get(i).checkCollision(p)) {
                pelletList.get(i).image = null;
            }
            if (pelletList.get(i).isEaten(p) == 1) {
                points += 1;
                pelletList.get(i).eaten = 100;
            }
        }
        if (p.getLives() > 0) {
            p.changeImage(images[(int)current]);
        }
        if (p.getLives() <= 0) {
            p.xv = 0;
            p.yv = 0;
            lose(p);
        }
        p.turn();
        p.setX(p.getX() + p.xv);
        p.setY(p.getY() + p.yv);        
    }
    private void render() { //Draws the images on the screen
        game.repaint();
        g = game.getGraphics();
        game.paintComponent(g);
        /*for (int i=0; i<pelletList.size(); i++) {
            pelletList.get(i).display(g, pelletList.get(i).image);
        }*/
        p.display(g, p.image);
    }
    public void run() {
        init();
        int fps = 60;
        double timePerTick = 1000000000/fps;
        double delta = 0;
        long now;
        long lastTime = System.nanoTime();
        while (running) {
            now = System.nanoTime();
            delta += (now - lastTime) / timePerTick;
            lastTime = now;
            if (delta >= 1) {
                tick();
                render();
                delta--;
            }
        }
        stop();
    }
    public synchronized void start() {
        if (running) {
            return;
        }
        thread = new Thread(this);
        thread.start();
        running = true;
    }
    public synchronized void stop() {
        if (!running) {
            return;
        }
        try {
            thread.join();
        } catch (InterruptedException e) {
            //TODO: handle exception
            e.printStackTrace();
        }
    }
    public BufferedImage loadImage(String s) {
        BufferedImage img = null;
        try {
            img = ImageIO.read(new File(s));
        } catch (IOException e) {
            System.out.println("File not found");
        }
        return img;
    }
    public void keyTyped(KeyEvent e) {
        return;
    }

    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();
        if (key == KeyEvent.VK_RIGHT) {
            p.queueTurn(0);
        }
        if (key == KeyEvent.VK_LEFT) {
            p.queueTurn(180);
        }
        if (key == KeyEvent.VK_UP) {
            p.queueTurn(270);
        }
        if (key == KeyEvent.VK_DOWN) {
            p.queueTurn(90);
        }
        if (key == KeyEvent.VK_1) {
            System.out.println(points);
        }
        if (key == KeyEvent. VK_2) {
            p.setLives(0);
        }
    }

    public void keyReleased(KeyEvent e) {
        return;
    }
    
    private void createPellets() {
		BufferedImage pelletimg = loadImage("Pellet.png");
		int [][] gamematrix = game.wall.getGameMatrix();
		int index = 0;
			
		for (int i = 0; i < gamematrix.length; i++) {
			for (int j = 0; j < gamematrix[i].length; j++) {
				if (gamematrix[i][j] == 0) {
					pelletList.add(index, new Pellet(i, j, 5, 5, pelletimg, game.wall));
					index++;
				}
			}
		}
	}
    public void restart() {
        p.setLives(3);
        p.restart();
    }
    public void lose(Pacman pacman) {
        losingImage += 0.1;
        if (losingImage > 7) {
            losingImage = 0;
            restart();
        }
        pacman.image = losingImages[(int)losingImage];
    }
}
