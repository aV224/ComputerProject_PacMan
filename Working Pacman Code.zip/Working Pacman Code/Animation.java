import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.*;
import javax.swing.*;
import java.awt.event.*;
public class Animation implements Runnable {

    private boolean running = false;
    private Thread thread;
    BufferedImage i = loadImage("pacman1.png");
    Pacman p = new Pacman(0, 0, i);
    GamePanel game = new GamePanel();
    Graphics g;
    private double current = 0;
    BufferedImage[] images = new BufferedImage[8];
    private int totalImages = images.length;
    private int xv;
    private int yv;

    private BufferedImage[] createImages(BufferedImage[] x) {
        BufferedImage[] imageArray = new BufferedImage[x.length];
        for (int k=0; k<x.length; k++) {
            int num = k+1;
            BufferedImage image = loadImage("pacman" + num + ".png");
            imageArray[k] = image;
        }
        return imageArray;
    }
    
    private void init() {
        JFrame frame = new JFrame("test");
        frame.setSize(500, 500);
        frame.setLocation(200, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setContentPane(game); 
        frame.setVisible(true);
        frame.getContentPane().setFocusable(true);
        frame.getContentPane().setFocusTraversalKeysEnabled(false);
        frame.getContentPane().addKeyListener(new KeyInput(this));
        images = createImages(images);
    }
    private void tick() { //updates the game
        game.repaint();
        current += 0.5;
        if (current >= totalImages) {
            current = 0;
        }
        p.changeImage(images[(int)current]);
        p.setX(p.getX() + xv);
        p.setY(p.getY() + yv);
    }
    private void render() { //Draws the images on the screen
        g = game.getGraphics();
        game.paintComponent(g);
        p.display(g, p.image);
    }
    public void run() {
        init();
        int fps = 60;
        double timePerTick = 1000000000/fps;
        double delta = 0;
        long now;
        long lastTime = System.nanoTime();
        while (running) {
            now = System.nanoTime();
            delta += (now - lastTime) / timePerTick;
            lastTime = now;
            if (delta >= 1) {
                tick();
                render();
                delta--;
            }
        }
        stop();
    }
    public synchronized void start() {
        if (running) {
            return;
        }
        thread = new Thread(this);
        thread.start();
        running = true;
    }
    public synchronized void stop() {
        if (!running) {
            return;
        }
        try {
            thread.join();
        } catch (InterruptedException e) {
            //TODO: handle exception
            e.printStackTrace();
        }
    }
    public BufferedImage loadImage(String s) {
        BufferedImage img = null;
        try {
            img = ImageIO.read(new File(s));
        } catch (IOException e) {
            System.out.println("File not found");
        }
        return img;
    }
    public void keyTyped(KeyEvent e) {
        return;
    }

    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();
        if (key == KeyEvent.VK_RIGHT) {
            p.setDirection(0);
            xv = 1;
            yv = 0;
        }
        if (key == KeyEvent.VK_LEFT) {
            p.setDirection(180);
            xv = -1;
            yv = 0;
        }
        if (key == KeyEvent.VK_UP) {
            p.setDirection(270);
            xv = 0;
            yv = -1;
        }
        if (key == KeyEvent.VK_DOWN) {
            p.setDirection(90);
            xv = 0;
            yv = 1;
        }
    }

    public void keyReleased(KeyEvent e) {
        return;
    }
}
