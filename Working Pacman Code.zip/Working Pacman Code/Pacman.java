import java.awt.image.BufferedImage;
public class Pacman extends Sprite {
    /**
     * startX holds the starting x coordinate
     */
    private final int startX = 0;
    /**
     * startY holds the starting y coordinate
     */
    private final int startY = 0;
    /**
     * lives stores the number of lives Pacman has
     */
    private int lives = 3;
    private int[] moves = new int[4];
    private int nextMove;
    /**
     * constructor for pacman. (extends Sprite)
     */
    public Pacman(int a, int b, int w, int h, BufferedImage i, PacWall pwall) {
        super(a, b, w, h, i, pwall);
    }
    /**
     * Queues turn for pacman. When the side is clear, it will turn
     */
    public void queueTurn(int dir) {
        if (dir == 0) {
            moves[0] = 1;
            moves[1] = 0;
            moves[2] = 0;
            moves[3] = 0;
        }
        if (dir == 90) {
            moves[0] = 0;
            moves[1] = 1;
            moves[2] = 0;
            moves[3] = 0;
        }
        if (dir == 180) {
            moves[0] = 0;
            moves[1] = 0;
            moves[2] = 1;
            moves[3] = 0;
        }
        if (dir == 270) {
            moves[0] = 0;
            moves[1] = 0;
            moves[2] = 0;
            moves[3] = 1;
        }
    }
    public int[] getMoves() {
        return moves;
    }
    public boolean hasNextMove() {
        for (int i=0; i<moves.length; i++) {
            if (moves[i] == 1) {
                nextMove = i;
                return true;
            }
        }
        nextMove = -1;
        return false;
    }
    /**
     * Moves pacman back to starting point
     */
    public void restart() {
        this.setDirection(0);
        this.setX(startX);
        this.setY(startY);
    }
    /**
     * returns the number of lives pacman has
     * @return int lives
     */
    public int getLives() {
        return lives;
    }
    public void setLives(int x) {
        lives = x;
    }
    public void turn() {
        if (hasNextMove()) {
            if (nextMove == 0 && rightIsClear(getWall())) {
                turnRight();
            }
            if (nextMove == 1 && downIsClear(getWall())) {
                turnDown();
            }
            if (nextMove == 2 && leftIsClear(getWall())) {
                turnLeft();
            }
            if (nextMove == 3 && upIsClear(getWall())) {
                turnUp();
            }
        }
    }
}