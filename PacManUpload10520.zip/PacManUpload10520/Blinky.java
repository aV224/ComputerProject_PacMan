/**
 * Author: Aarya Vijayaraghavan
 */
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Blinky extends Sprite {
	
	private PacMan pacMan = null;
	private PacWall wall = null;

	enum directions {
		RIGHT,
		LEFT,
		UP,
		DOWN
		}
	private directions currDirection = directions.UP;
	
	public Blinky (PacMan pacman, PacWall wall) {
		try {
			img = ImageIO.read(new File("Blinky.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		xAxis = 260;
		yAxis = 340;
		width = 20;
		height = 20;
		this.pacMan = pacman;
		this.wall = wall;
	}
	
	public void paintGhost(Graphics2D g2d) {
		g2d.drawImage(img, xAxis, yAxis, width, height, null);
	}
	
	public boolean makeNextMove() {
		int targetx = pacMan.getxAxis();
		int targety = pacMan.getyAxis();
		directions dir = this.currDirection;
		int tmpvar = 0;
		int relvar = 0;
		
		boolean xless = wall.isClear(xAxis - 1, yAxis);
		boolean xmore = wall.isClear(xAxis + 1, yAxis);
		boolean yless = wall.isClear(xAxis, yAxis - 1);
		boolean ymore = wall.isClear(xAxis, yAxis + 1);
		
		if (dir == directions.RIGHT) {
			tmpvar = xAxis + 1;
			relvar = ((tmpvar % moduloValue) == 0) ? 0 : (moduloValue - (tmpvar % moduloValue));
			if (wall.isClear((tmpvar + relvar), yAxis)) {
				xAxis += 1;
			} else if (yless && ymore) {
				if (targety > yAxis) {
					currDirection = directions.DOWN;
				} else if (targety < yAxis) {
					currDirection = directions.UP;
				}
			} else if (!(yless) && ymore) {
				currDirection = directions.DOWN;
			} else if (yless && !(ymore)) {
				currDirection = directions.UP;
			}
		}
		else if (dir == directions.LEFT) {	
			if ((xAxis % moduloValue) == 0) {
				tmpvar = xAxis - 1;
			} else {
				tmpvar = xAxis - 1;
				tmpvar = tmpvar + (moduloValue - (tmpvar % moduloValue));
			}
			if (wall.isClear(tmpvar, yAxis)) {
				xAxis -= 1;
			} else if (yless && ymore) {
				if (targety > yAxis) {
					currDirection = directions.DOWN;
				} else if (targety < yAxis) {
					currDirection = directions.UP;
				}
			} else if (!(yless) && ymore) {
				currDirection = directions.DOWN;
			} else if (yless && !(ymore)) {
				currDirection = directions.UP;
			}
		}
		else if (dir == directions.UP) {
			if ((yAxis % moduloValue) == 0) {
				tmpvar = yAxis - 1;
			} else {
				tmpvar = yAxis - 1;
				tmpvar = tmpvar + (moduloValue - (tmpvar % moduloValue));
			}
			if (wall.isClear(xAxis, tmpvar)) {
				yAxis -= 1;
			} else if (xless && xmore) {
				if (targetx > xAxis) {
					currDirection = directions.RIGHT;
				} else if (targetx < xAxis) {
					currDirection = directions.LEFT;
				}
			} else if (!(xless) && xmore) {
				currDirection = directions.RIGHT;
			} else if (xless && !(xmore)) {
				currDirection = directions.LEFT;
			}
		}
		else if (dir == directions.DOWN) {
			tmpvar = yAxis + 1;
			relvar = ((tmpvar % moduloValue) == 0) ? 0 : (moduloValue - (tmpvar % moduloValue));
			if (wall.isClear(xAxis, (tmpvar + relvar))) {
				yAxis += 1;
			} else if (xless && xmore) {
				if (targetx > xAxis) {
					currDirection = directions.RIGHT;
				} else if (targetx < xAxis) {
					currDirection = directions.LEFT;
				}
			} else if (!(xless) && xmore) {
				currDirection = directions.RIGHT;
			} else if (xless && !(xmore)) {
				currDirection = directions.LEFT;
			} 
		}
		return (checkCollision(pacMan));
	}
	
	@Override
	public Rectangle getBounds() {
		return new Rectangle(xAxis, yAxis, 20, 20);
	}
}