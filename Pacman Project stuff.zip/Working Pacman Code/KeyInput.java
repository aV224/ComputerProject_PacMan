import java.awt.event.*;
public class KeyInput implements KeyListener {
    Animation animation;
    public KeyInput(Animation a) {
        animation = a;
    }
    public void keyTyped(KeyEvent e) {
        animation.keyTyped(e);
    }
    public void keyPressed(KeyEvent e) {
        animation.keyPressed(e);
    }
    public void keyReleased(KeyEvent e) {
        animation.keyReleased(e);
    }
}
