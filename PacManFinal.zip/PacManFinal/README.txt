Step 1: Download the zipped file
Step 2: Open GameDriver.java
Step 3: Click run
Step 4: A frame will pop up; click play to play the game
Step 5: Enjoy!

How the player is controlled:
The player is controlled using the arrow keys.
You must hold the arrow keys in order to make the player move
You must line up your player exactly at the middle of the turn in order to turn
This game does not queue turns. You must turn when the turn is available.
