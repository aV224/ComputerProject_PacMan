/**
 * GameDriver controls all frames and panels. 
 * 
 * @author Aarya Vijayaraghavan
 * @author Aiden Cheong
 * @author Max Wang
 */

import javax.swing.*;
import javax.swing.SwingUtilities;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.awt.Point.*;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

public class GameDriver implements Runnable{
  
   public static void main(String[] args) {
      // Alerts java that we are using Thread and Swing.
      SwingUtilities.invokeLater(new GameDriver());
   }   
   
   /**
   * Creates a vertical buffer to be used anywhere
   */
   
   private static void addVerticalBuffer(int height, Container container) {
      container.add(Box.createRigidArea(new Dimension(200, height)));
   }

   /**
   * Renders main menu.
   */
   
   @Override
   public void run() {
      // Run is the main method used in this class. It draws the main menu, and gives options to play or exit.
         
      JFrame frame = new JFrame();
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setPreferredSize(new Dimension(250, 175));
      frame.setVisible(true);
      
      JPanel menuPanel = new JPanel();
      menuPanel.setFocusable(true);
      menuPanel.setLayout(new BoxLayout(menuPanel, BoxLayout.Y_AXIS));

      Dimension bd = new Dimension(150,25);
      
      addVerticalBuffer(10, menuPanel);
               
      JLabel titleLabel = new JLabel("PACMAN", SwingConstants.CENTER);
      titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
      titleLabel.setFont(new Font("Dialog", Font.BOLD, 20));
      titleLabel.setForeground(Color.black);
      menuPanel.add(titleLabel);
      
      addVerticalBuffer(10, menuPanel);
      
      JLabel titleLabel2 = new JLabel("Written by Aarya V., Aiden C., and Max W.", SwingConstants.CENTER);
      titleLabel2.setAlignmentX(Component.CENTER_ALIGNMENT);
      titleLabel2.setFont(new Font("Dialog", Font.PLAIN, 10));
      titleLabel2.setForeground(Color.black);
      menuPanel.add(titleLabel2);
      
      addVerticalBuffer(10, menuPanel);
           
      JButton gameB = new JButton("Play");
      gameB.setFont(new Font("Dialog", Font.PLAIN, 15));
      gameB.setAlignmentX(Component.CENTER_ALIGNMENT);
      gameB.setMinimumSize(bd);
      gameB.setPreferredSize(bd);
      gameB.setMaximumSize(bd);
      menuPanel.add(gameB);
      
      addVerticalBuffer(5, menuPanel);
          
      JButton exitB = new JButton("Exit");
      exitB.setFont(new Font("Dialog", Font.PLAIN, 15));
      exitB.setAlignmentX(Component.CENTER_ALIGNMENT);
      exitB.setMinimumSize(bd);
      exitB.setPreferredSize(bd);
      exitB.setMaximumSize(bd);
      menuPanel.add(exitB);
      
      addVerticalBuffer(5, menuPanel);
   
      frame.add(menuPanel);
      frame.pack();
      
      // gameB and exitB will run the game or exit the game, respectively.
      
      gameB.addActionListener(
            new ActionListener() {
               @Override
               public void actionPerformed(ActionEvent evt) {
                  frame.dispose();
                  Thread gameThread = new Thread() {
                     public void run() {
                        startGame();
                     }
                  };
                  gameThread.start();
               }
            });
         
      exitB.addActionListener(
            new ActionListener() {
               @Override
               public void actionPerformed(ActionEvent evt) {
                  System.exit(0);
               }
            });
   
   }
   
   public void endFrame(int result, int score) {
      // After the game ends, this Panel will show results and give options to leave or retry.   
         
      JFrame frame = new JFrame();
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setPreferredSize(new Dimension(250, 200));
      frame.setVisible(true);
      
      JPanel menuPanel = new JPanel();
      menuPanel.setFocusable(true);
      menuPanel.setLayout(new BoxLayout(menuPanel, BoxLayout.Y_AXIS));

      Dimension bd = new Dimension(150,25);
      
      addVerticalBuffer(10, menuPanel);
      
      switch(result) {
         case 1:        
            JLabel titleLabel = new JLabel("You Win!", SwingConstants.CENTER);
            titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            titleLabel.setFont(new Font("Dialog", Font.BOLD, 20));
            titleLabel.setForeground(Color.black);
            menuPanel.add(titleLabel);
            addVerticalBuffer(10, menuPanel);
            JLabel titleLabel2 = new JLabel("Final Score: MAXOUT", SwingConstants.CENTER);
            titleLabel2.setAlignmentX(Component.CENTER_ALIGNMENT);
            titleLabel2.setFont(new Font("Dialog", Font.BOLD, 15));
            titleLabel2.setForeground(Color.black);
            menuPanel.add(titleLabel2);
            addVerticalBuffer(10, menuPanel);
            break;
         case -1:
            JLabel titleLabel3 = new JLabel("You Lose...", SwingConstants.CENTER);
            titleLabel3.setAlignmentX(Component.CENTER_ALIGNMENT);
            titleLabel3.setFont(new Font("Dialog", Font.BOLD, 20));
            titleLabel3.setForeground(Color.black);
            addVerticalBuffer(10, menuPanel);
            menuPanel.add(titleLabel3);
            JLabel titleLabel4 = new JLabel("Final Score: "+score, SwingConstants.CENTER);
            titleLabel4.setAlignmentX(Component.CENTER_ALIGNMENT);
            titleLabel4.setFont(new Font("Dialog", Font.BOLD, 15));
            titleLabel4.setForeground(Color.black);
            addVerticalBuffer(10, menuPanel);
            menuPanel.add(titleLabel4);
            break;
      }
       
      // Two buttons are used: one to return to the main menu and one to end the game. 
           
      JButton menuB = new JButton("Main Menu");
      menuB.setFont(new Font("Dialog", Font.PLAIN, 15));
      menuB.setAlignmentX(Component.CENTER_ALIGNMENT);
      menuB.setMinimumSize(bd);
      menuB.setPreferredSize(bd);
      menuB.setMaximumSize(bd);
      menuPanel.add(menuB);
      
      addVerticalBuffer(5, menuPanel);
          
      JButton exitB = new JButton("Exit");
      exitB.setFont(new Font("Dialog", Font.PLAIN, 15));
      exitB.setAlignmentX(Component.CENTER_ALIGNMENT);
      exitB.setMinimumSize(bd);
      exitB.setPreferredSize(bd);
      exitB.setMaximumSize(bd);
      menuPanel.add(exitB);
      
      addVerticalBuffer(5, menuPanel);
   
      frame.add(menuPanel);
      frame.pack();
      
      // menuB will rerun the game from the start, and exitB will exit the game.
      
      menuB.addActionListener(
            new ActionListener() {
               @Override
               public void actionPerformed(ActionEvent evt) {
                  frame.dispose();
                  run();
               }
            });
         
      exitB.addActionListener(
            new ActionListener() {
               @Override
               public void actionPerformed(ActionEvent evt) {
                  System.exit(0);
               }
            });
   
   }     
   
   /**
   * Runs game as PacPanel on a new frame, loops gameUpdate until game ends.
   */ 
   
   public void startGame() {
      System.out.println("Starting a game!");
      JFrame pacFrame = new JFrame("Testing Wall");
		PacPanel pPanel = new PacPanel();

		pPanel.setPreferredSize(new Dimension(560, 700));
		pacFrame.add(pPanel);
		pacFrame.setSize(560, 700);
		pacFrame.setVisible(true);
		pacFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pacFrame.pack();
            
      while (true) {
         int result = pPanel.gameupdate();
         int score = pPanel.getScore();
         if (result == -1) {
            System.out.println("Game Ended!!");
            pacFrame.dispose();
            endFrame(-1, score);
            break;
         } else if (result == 1) {
            System.out.println("Game won");
            pacFrame.dispose();
            endFrame(1, score);
            break;
         }
         try {
            Thread.sleep(20);
         } catch (InterruptedException e) {
            e.printStackTrace();
         }
      }
   }
}
